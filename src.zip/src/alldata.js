// //import UserContext from "./context";
// //import { useContext } from "react";
// import axios from "axios";
// import { useState,useEffect } from "react"
// export default function Alldata(){
// //let users=useContext(UserContext)
// //console.log("hii",users.users[0].amount)
// let [data,setData]=useState([])
// async function handleClick(e){
//   e.preventDefault();
//  let result= await (axios.get('http://localhost:8080/data'))
//  setData(result.data)
// }
// return(
// <>
// <h1>ALL-DATA</h1>
// <table class="table">
//   <thead>
//     <tr>
//       <th scope="col">NAME</th>
//       <th scope="col">E-MAIL</th>
//       <th scope="col">PASSWORD</th>
//       <th scope="col">HANDLE</th>
//     </tr>
//   </thead>
//   <tbody>
//    { data.map((item)=><tr>
//     <td>{item.name}</td>
//    <td>{item.email}</td>
//    <td>{item.password}</td>
//    <td>{item.amount}</td>
//    </tr>)}
//   </tbody>
// </table>
// <button onClick={handleClick}>FETCH</button>
// </>)
// }

// import UserContext from "./context";
// import { useContext } from "react";
// export default function Alldata(){
// let users=useContext(UserContext)
// console.log("hii",users.users[0].amount)

// return(
// <>
// <h1>ALL-DATA</h1>
// <table class="table">
//   <thead>
//     <tr>
//       <th scope="col">NAME</th>
//       <th scope="col">E-MAIL</th>
//       <th scope="col">PASSWORD</th>
//       <th scope="col">HANDLE</th>
//     </tr>
//   </thead>
//   <tbody>
//    { users.users.map((item)=><tr>
//     <td>{item.name}</td>
//    <td>{item.email}</td>
//    <td>{item.password}</td>
//    <td>{item.amount}</td>
//    </tr>)}   
//   </tbody>
// </table>
// </>)
// }
// import UserContext from "./context";
// import { useContext } from "react";
// export default function Alldata(){
// let users=useContext(UserContext)
// console.log("hii",users.users[0].amount)


// return(
// <>
// <h1>ALL-DATA</h1>
// <table class="table">
//   <thead>
//     <tr>
//       <th scope="col">NAME</th>
//       <th scope="col">E-MAIL</th>
//       <th scope="col">PASSWORD</th>
//       <th scope="col">HANDLE</th>
//     </tr>
//   </thead>
//   <tbody>
//    { users.users.map((item)=><tr>
//     <td>{item.name}</td>
//    <td>{item.email}</td>
//    <td>{item.password}</td>
//    <td>{item.amount}</td>
//    </tr>)}
   

    
//   </tbody>
// </table>
// </>)
// }



import UserContext from "./context";
import { useContext, useState } from "react";
export default function Alldata() {
    const { users, setUsers } = useContext(UserContext);
    const [editUser, setEditUser] = useState(null);
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [amount, setAmount] = useState('');
    const handleEdit = (user) => {
        setEditUser(user);
        setName(user.name);
        setEmail(user.email);
        setPassword(user.password);
        setAmount(user.amount);
    };
    const handleUpdate = () => {
        const updatedUsers = users.map(user => 
            user.email === editUser.email ? { ...user, name, email, password, amount } : user
        );
        setUsers(updatedUsers);
        resetForm();
    };
    const handleDelete = (email) => {
        const filteredUsers = users.filter(user => user.email !== email);
        setUsers(filteredUsers);
    };
    const resetForm = () => {
        setEditUser(null);
        setName('');
        setEmail('');
        setPassword('');
        setAmount('');
    };
    return (
        <>
            <h1>ALL-DATA</h1>
            <table className="table">
                <thead>
                    <tr>
                        <th scope="col">NAME</th>
                        <th scope="col">E-MAIL</th>
                        <th scope="col">PASSWORD</th>
                        <th scope="col">HANDLE</th>
                        <th scope="col">ACTIONS</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map((item) => (
                        <tr key={item.email}>
                            <td>{item.name}</td>
                            <td>{item.email}</td>
                            <td>{item.password}</td>
                            <td>{item.amount}</td>
                            <td>
                                <button onClick={() => handleEdit(item)}>Edit</button>
                                <button onClick={() => handleDelete(item.email)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            {editUser && (
                <div>
                    <h2>Edit User</h2>
                    <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" />
                    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
                    <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" />
                    <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Amount" />
                    <button onClick={handleUpdate}>Update</button>
                    <button onClick={resetForm}>Cancel</button>
                </div>
            )}
        </>
    );
}